<?php global $adforest_theme;
if( isset( $adforest_theme['scroll_to_top'] ) && $adforest_theme['scroll_to_top'] )
{
?>
<a href="#0" class="cd-top"><?php echo __( 'Top', 'adforest' ); ?></a>
<?php
}
?>