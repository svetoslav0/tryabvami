<footer>
	<div class="footer-copyright">
       <div class="container clearfix">
          <!--Copyright-->
          <div class="copyright text-center">
		<?php

                echo wp_kses( "Copyright 2017 &copy; Theme Created By <a href='https://themeforest.net/user/scriptsbundle/portfolio'>ScriptsBundle</a> All Rights Reserved.", adforest_required_tags() );
        ?>
          </div>
       </div>
    </div>
</footer>