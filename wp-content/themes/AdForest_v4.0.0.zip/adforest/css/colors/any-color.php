<?php 



 'a , a:hover {
     color: #f58936;
}
 .box h4 a:hover, .category-grid-box .short-description h3 a:hover, .category-grid-box .view-details:hover, .ad-listing .ad-content h3 a:hover, .car-details h4:hover, .post-title a:hover, .post-info a:hover, .popular-categories li a:hover, .font-color, .ad-location-gird .location-title-disc h5:hover, .ad-location-gird .location-title-disc h5 a:hover, .footer-content .footer-widget .contact-info li:hover, .footer-content .footer-widget.links-widget li a:hover, .footer-content .news-widget .news-post a:hover, ul.category-list-style li a:hover, .funfacts h4 span, .singlepost-content .descs-box .short-history li b, .singlepost-content .descs-box .short-history li b a, .descs-box i, .share-ad .modal-body p a, .item-date a, .blog-sidebar .widget .widget-content .tagcloud a:hover, .blog-sidebar .widget .widget-content ul li a:hover, .comming-soon-grid .count-down #clock > span, .features .features-text h3:hover, .features .features-text h3 a:hover, .site-map-list li a:hover , .header-top ul li a:hover, .ad-archive-desc h3:hover, .ad-archive-desc h3 a:hover , .footer-area .contact-info li .icon , .heading-color , .ad-preview-details .overview-price span , .ad-listing .content-area .price , .category-grid-box-1 a:hover, .category-grid i , .hero .content p:first-child b , ul.category-list-data li:hover::before, ul.category-list-data li:hover a , ul.category-list-data li:hover a span , .category-list-title h5 > a:hover , .view-more a:hover , .category-grid-box .short-description .price , .ad-price, ul.category-list-style li:hover a i , .sidebar .side-menu nav .nav > li > a:hover , .filter-brudcrums-sort ul li a:hover , .skin-minimal .list li label:hover , .advertising .banner .submit , .recent-ads .recent-ads-list-price , .bread-3.page-header-area .small-breadcrumb .breadcrumb-link ul li a.active , .ad .content-zone .short-description-1 h3 a:hover , .user-profile ul li:hover a, .user-profile ul li.active a , .dashboard-menu-container ul li.active .menu-name , .dashboard-menu-container ul li:hover .menu-name , .tags-share .tags ul li a , .comment-list .comment .comment-info .author-desc .author-title li a:hover , .why-us:hover i, .why-us:hover h5 , .card .nav-tabs > li.active > a, .card .nav-tabs > li > a:hover , .accordion-title a:hover , .usefull-info .info-content h3:hover, .mega-menu .drop-down a:hover, .mega-menu .drop-down-tab-bar a:hover , .recent-ads .recent-ads-list-title a:hover , .singleContadds i , .white.category-grid-box-1 .ad-info-1 ul li:hover, .white.category-grid-box-1 .ad-info-1 ul li a:hover , .ad-listing .content-area h3 a:hover , .widget.widget-content ul li a:hover , body .woocommerce table.shop_table tr.cart_item td a:hover , body .woocommerce table.shop_table td.product-remove a.remove:hover , .blog-post .post-excerpt a strong:hover , .category-list:hover .category-list-title h5 a , .category-list:hover .view-more a , .copyright-content p a , .content-zone .short-description-1 .list-3-short-info li a:hover , .single-blog.blog-detial .blog-post .post-excerpt p a, .message-inbox .message-header span a:hover, .message-inbox .message-header span a.active, .footer-top .widget.my-quicklinks ul li a:hover , .listing-detail .listing-content .listing-title a:hover , .listing-detail .listing-content ul li span span.padding_cats a:hover , .new-small-grid-description h3 a:hover, .category_gridz .title:hover {
     color: #f58936;
}
 .woocommerce table.shop_table td .button:hover, .wc-proceed-to-checkout .button:hover, .place-order .button:hover , .woocommerce #respond input#submit.alt:hover , .woocommerce a.button.alt:hover , .woocommerce button.button.alt:hover , .woocommerce input.button.alt:hover{
     background-color: #dc7b30 ;
     border: 1px solid #dc7b30 ;
}
 .woocommerce #respond input#submit, .woocommerce a.button, .woocommerce button.button, .woocommerce input.button , .woocommerce #respond input#submit.alt , .woocommerce a.button.alt, .woocommerce button.button.alt, .woocommerce input.button.alt {
     text-transform: uppercase;
     background-color: #f58936;
     border-color: #f58936;
     border: 1px solid #f58936 ;
}
 .single-blog.blog-detial .blog-post .post-excerpt blockquote {
     border-left: 5px solid #f58936;
}
 .post-password-form input[type="submit"] {
     background: #f58936 none repeat scroll 0 0;
     border: 1px solid #f58936;
     color: #fff;
     padding: 2px 30px;
}
 .featured-slider .owl-controls .owl-nav .owl-next:hover, .featured-slider .owl-controls .owl-nav .owl-prev:hover .ms-layer.btn3:hover, .home-category-slider .category-slider .owl-controls .owl-nav .owl-next:hover, .home-category-slider .category-slider .owl-controls .owl-nav .owl-prev:hover, .subscribe button:hover , .featured-slider-1 .owl-controls .owl-nav .owl-next:hover, .featured-slider-1 .owl-controls .owl-nav .owl-prev:hover , .sticky-post-button:hover , .btn-light:hover , .featured-slider-3 .owl-controls .owl-nav .owl-next:hover, .featured-slider-3 .owl-controls .owl-nav .owl-prev:hover , .hero-form-sub li a:hover , #google-map-btn a:hover , .modern-version-block-cat:hover , .featured-slider-5 .owl-controls .owl-nav .owl-next:hover, .featured-slider-5 .owl-controls .owl-nav .owl-prev:hover {
     background-color: #dc7b30 !important;
}
 .btn-success {
     background-color: #f58936 !important;
     border-color: #f6944a !important;
}
 .btn-success:hover {
     background-color: #dc7b30 !important;
     border-color: #f6944a !important;
}
 .app-download-button.hover, .app-download-button:hover, .app-download-button.focus, .app-download-button:focus, .app-download-button:active, .app-download-button.active, .ms-layer.btn3, .minimal-footer-1 .widget .social-links a:hover, .subscribe button, .social-area-share > a:hover , .search-section .search-options > li .btn.btn-danger:hover , .featured-slider-1 .owl-controls .owl-nav .owl-next, .featured-slider-1 .owl-controls .owl-nav .owl-prev , .featured-slider .owl-controls .owl-nav .owl-next, .featured-slider .owl-controls .owl-nav .owl-prev, .category-grid-box-1 .price-tag .price span , .featured-slider-3 .owl-controls .owl-nav .owl-next, .featured-slider-3 .owl-controls .owl-nav .owl-prev , .small-breadcrumb .breadcrumb-link ul li a::after , .user-profile .badge , .ps-container > .ps-scrollbar-y-rail > .ps-scrollbar-y , .sticky-post-button , .select2-container--default .select2-results__option--highlighted[aria-selected] , .mega-menu .menu-links > li.activeTriggerMobile , .dropdown-menu > li > a:hover, .dropdown-menu > li > a:focus , .featured-slider-5 .owl-controls .owl-nav .owl-next, .featured-slider-5 .owl-controls .owl-nav .owl-prev, .featured-slider-3.owl-carousel .owl-nav button.owl-next, .featured-slider-3.owl-carousel .owl-nav button.owl-prev, .owl-carousel button.owl-dot, .owl-carousel .owl-nav button.owl-next:hover, .owl-carousel .owl-nav button.owl-prev:hover, .owl-carousel button.owl-dot:hover{
     background-color: #f58936 !important;
}
 span.app-store-btn:hover, .social-links-two a:hover , .search-section .search-options > li .btn.btn-danger:hover {
    border: 1px solid #f58936 !important;
}
 .slide-thumbnail .flex-active-slide img {
     border-color: #f58936 !important;
}
 .pagination > .active > a:hover, .pagination li:hover > a, .pagination > .active > a , .category-grid .custom-cat:hover , .pricing .featured a.btn-theme:hover , .btn-orange {
     background-color: #f58936;
     border-color: #dc7b30;
     color: #fff !important;
}
 .small-breadcrumb .breadcrumb-link ul li a.active {
     border-bottom: 4px solid #f58936;
     color: #f58936;
     font-weight: 600;
}
 .popup-cls.close::before {
     border-color: rgba(0, 0, 0, 0) #f58936;
    border-style: solid;
    border-width: 0 70px 70px 0;
    content: "";
    display: block;
    height: 0;
    position: absolute;
    right: 0;
    top: 0;
    width: 0;
    z-index: -1;
}
 .grid-panel .location-icon i , .widget-newsletter .fieldset form .submit-btn , .ad-listing .content-area .additional-info li a:hover , .noUi-connect , .card .nav-tabs > li > a::after , .ad-listing-price p , .mega-menu .drop-down-multilevel li.activeTriggerMobile , .mega-menu .drop-down-multilevel li:hover , .blog-sidebar .widget.widget-content .tagcloud a:hover, .new-shortcode .tab .nav-tabs li.active a, .new-shortcode .tab .nav-tabs li a:hover{
     background: #f58936 none repeat scroll 0 0 !important;
}
 .cd-top {
     background: #f58936 url(../../images/cd-top-arrow.svg) no-repeat center 50%;
}
 .heading-panel h3.main-title {
     border-bottom: 2px solid #f58936;
}
 .mega-menu .drop-down a, .mega-menu .drop-down-tab-bar a {
     color:#232323;
}
 .mega-menu .menu-search-bar li .btn:hover{
     color:#fff;
}
 .btn-theme , .btn-light {
     color: #ffffff;
     background-color: #f58936;
     border-color: #f6944a;
}
 .btn-theme:hover, .btn-theme:focus, .btn-theme:active, .btn-theme.active, .open .dropdown-toggle.btn-theme , .btn-orange:hover{
     color: #ffffff;
     background-color: #dc7b30;
     border-color: #f6944a;
}
 .btn-theme:active, .btn-theme.active, .open .dropdown-toggle.btn-theme {
     background-image: none;
}
 .btn-theme.disabled, .btn-theme[disabled], fieldset[disabled] .btn-theme, .btn-theme.disabled:hover, .btn-theme[disabled]:hover, fieldset[disabled] .btn-theme:hover, .btn-theme.disabled:focus, .btn-theme[disabled]:focus, fieldset[disabled] .btn-theme:focus, .btn-theme.disabled:active, .btn-theme[disabled]:active, fieldset[disabled] .btn-theme:active, .btn-theme.disabled.active, .btn-theme[disabled].active, fieldset[disabled] .btn-theme.active {
     background-color: #f58936;
     border-color: #f6944a;
}
 .btn-theme .badge {
     color: #f58936;
     background-color: #ffffff;
}
 .country-box:hover .country-description {
     background-color: rgba(245, 137, 54, 0.86);
}
 .profile-tabs .nav-tabs {
     border-color: -moz-use-text-color -moz-use-text-color #f58936 ;
}
 .user-profile ul li.active a::before {
     border-left: 9px solid #f58936;
}
 .user-profile ul li.active a {
     border-left: 3px solid #f58936;
}
 .add-pages > span {
     color:#fff !important;
     background-color: #f58936 !important;
     border: 1px solid #f58936;
}
 ul.filterAdType li.active a, ul.filterAdType li a:hover {
     background: #f58936 none repeat scroll 0 0;
     color: #fff;
}
 .sb_tag {
     background: #f58936 !important;
}
 .mat-hero-text-section h2 span, .tech-mac-book h4 span, .tech-latest-primary-section h3 .explore-style, .tech-view-section h2 span, .land-classified-heading h3 span, .land-classified-text-section .list-inline li i, .land-qs-heading-section h3 span, .land-one-rating i{
    color:#f58936 !important;
}
 .tech-new-great-product .new-all-categories{
    background-color: #f58936 !important;
}
 .tech-new-prices strike {
     color: #f58936 !important;
}
 .land-one-slider-2 div.owl-dots button.owl-dot{
     background-color: transparent !important;
}
 .land-one-slider-2 div.owl-dots button.owl-dot:hover{
     padding: 4px 1px !important;
}
';