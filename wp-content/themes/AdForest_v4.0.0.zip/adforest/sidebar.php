<div class="col-md-4 col-xs-12 col-sm-12">
    <div class="blog-sidebar">
    	<?php dynamic_sidebar( 'sb_themes_sidebar' ); ?>
    </div>
</div>