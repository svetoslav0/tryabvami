<div class="lp_payment_steps_area">
	<!-- timeline on checkout page -->
	<ol class="lp-checkout-steps">
	  <li class="firstStep current"><span class="number">1</span><span class="description"><?php echo esc_html__('SELECT PAYMENT', 'listingpro-plugin'); ?></span></li>
	  <li class="secondStep current"><span class="number">2</span><span class="description"><?php echo esc_html__('REVIEW PAYMENT', 'listingpro-plugin'); ?></span></li>
	  <li class="thirdStep current"><span class="number">3</span><span class="description"><?php echo esc_html__('DONE', 'listingpro-plugin'); ?></span></li>
	</ol>
</div>